interface Brukergrensesnitt{

    void giStatus(String status);

    // returner indeks for alternativ
    int beOmKommando(String spoersmaal, String[] alternativer);

}
